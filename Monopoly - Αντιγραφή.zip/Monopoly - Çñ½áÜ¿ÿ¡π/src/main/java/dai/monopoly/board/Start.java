package dai.monopoly.board;

import dai.monopoly.Player;

public class Start extends Tile {

  public Start(){}

	public Start(String name, int position) {
		super(name, position);
		// TODO Auto-generated constructor stub
	}


	@Override
	public void landingActions(Player rechiverOfActions) {
		// TODO Auto-generated method stub

	}

}
