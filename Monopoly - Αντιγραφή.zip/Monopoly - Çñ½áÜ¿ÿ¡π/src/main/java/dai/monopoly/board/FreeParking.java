package dai.monopoly.board;

import dai.monopoly.Player;

public class FreeParking extends Tile {
  public FreeParking(){}

	public FreeParking(String name, int position) {
		super(name, position);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void landingActions(Player rechiverOfActions) {
		// TODO Auto-generated method stub

	}

}
