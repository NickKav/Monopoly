package dai.monopoly.board;

import dai.monopoly.Player;

public class Jail extends Tile {

  public Jail() {
  }

  public Jail(String name, int position) {
		super(name, position);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void landingActions(Player rechiverOfActions) {
		// TODO Auto-generated method stub

	}

}
