package dai.monopoly.board.properties;

public class Apofasi {

  public Apofasi(){}









}
