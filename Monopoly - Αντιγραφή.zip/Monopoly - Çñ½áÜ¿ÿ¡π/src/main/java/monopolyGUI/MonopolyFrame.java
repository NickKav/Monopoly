package monopolyGUI;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MonopolyFrame extends JFrame {
    private BoardPanel boardPanel;
    private ControlPanel controlPanel;

    public MonopolyFrame() {
        setTitle("Monopoly");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        List<BoardSpace> boardSpaces = initializeBoardSpaces();
        boardPanel = new BoardPanel(boardSpaces);
        controlPanel = new ControlPanel();

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(boardPanel, BorderLayout.CENTER);
        mainPanel.add(controlPanel, BorderLayout.EAST);

        add(mainPanel, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        setupActionListeners();
    }

    private void setupActionListeners() {
        controlPanel.getBuyButton().addActionListener(e -> controlPanel.displayMessage("Buy button clicked"));
        controlPanel.getPayButton().addActionListener(e -> controlPanel.displayMessage("Pay button clicked"));
        controlPanel.getRollDiceButton().addActionListener(e -> controlPanel.displayMessage("Roll Dice button clicked"));
        controlPanel.getEndTurnButton().addActionListener(e -> controlPanel.displayMessage("End Turn button clicked"));
    }

    private List<BoardSpace> initializeBoardSpaces() {
        List<BoardSpace> boardSpaces = new ArrayList<>();
        boardSpaces.add(new SpecialSpace("Go"));
        boardSpaces.add(new Property("Εγνατία", 60, 2));
        boardSpaces.add(new SpecialSpace("Σταθμος Δ"));
        boardSpaces.add(new Property("Τσιμησκή", 60, 4));
        boardSpaces.add(new SpecialSpace("Εντολή"));
        boardSpaces.add(new Station("Αριστοτέλους", 200, 25));
        boardSpaces.add(new Property("GO", 100, 6));
        
        boardSpaces.add(new SpecialSpace("Free Parking"));
        boardSpaces.add(new Property("Καλαμαριά", 140, 10));
        boardSpaces.add(new Utility("Εντολή", 150, 4));
        boardSpaces.add(new Property("Εύοσμος", 140, 10));
        boardSpaces.add(new Property("Σταθμός Β", 160, 12));
        boardSpaces.add(new Station("Λαγκαδά", 200, 25));
        boardSpaces.add(new Property("", 180, 14));
        
        boardSpaces.add(new SpecialSpace(""));
        boardSpaces.add(new Property("Ευαγγελίστρια", 220, 18));
        boardSpaces.add(new SpecialSpace("Σταθμός Α"));
        boardSpaces.add(new Property("Πυλαία", 220, 18));
        boardSpaces.add(new Property("Εντολή", 240, 20));
        boardSpaces.add(new Station("Χαριλάου", 200, 25));
        boardSpaces.add(new Property("Φυλακή", 260, 22));
        
        boardSpaces.add(new SpecialSpace("Go to Jail"));
        boardSpaces.add(new Property("Τούμπα", 300, 26));
        boardSpaces.add(new Property("Εντολή", 300, 26));
        boardSpaces.add(new SpecialSpace("Αγίου Δημητρίου"));
        boardSpaces.add(new Property("Σταθμός Γ", 320, 28));
        boardSpaces.add(new Station("Τριανδία", 200, 25));
        boardSpaces.add(new Property("", 350, 35));

        return boardSpaces;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MonopolyFrame());
    }
}





