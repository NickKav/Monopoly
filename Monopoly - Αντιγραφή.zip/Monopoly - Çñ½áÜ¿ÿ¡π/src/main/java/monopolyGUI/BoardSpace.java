package monopolyGUI;

abstract class BoardSpace {
    protected String name;

    public BoardSpace(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

class Property extends BoardSpace {
    private int price;
    private int rent;

    public Property(String name, int price, int rent) {
        super(name);
        this.price = price;
        this.rent = rent;
    }

    public int getPrice() {
        return price;
    }

    public int getRent() {
        return rent;
    }
}

class Station extends BoardSpace {
    private int price;
    private int rent;

    public Station(String name, int price, int rent) {
        super(name);
        this.price = price;
        this.rent = rent;
    }

    public int getPrice() {
        return price;
    }

    public int getRent() {
        return rent;
    }
}

class Utility extends BoardSpace {
    private int price;
    private int rentMultiplier;

    public Utility(String name, int price, int rentMultiplier) {
        super(name);
        this.price = price;
        this.rentMultiplier = rentMultiplier;
    }

    public int getPrice() {
        return price;
    }

    public int getRentMultiplier() {
        return rentMultiplier;
    }
}

class SpecialSpace extends BoardSpace {
    public SpecialSpace(String name) {
        super(name);
    }
}


