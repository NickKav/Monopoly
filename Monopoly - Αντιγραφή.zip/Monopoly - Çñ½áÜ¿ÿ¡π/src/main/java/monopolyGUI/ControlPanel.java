package monopolyGUI;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class ControlPanel extends JPanel {
    private JButton buyButton;
    private JButton payButton;
    private JButton rollDiceButton;
    private JButton endTurnButton;
    private JTextArea messageArea;

    public ControlPanel() {
        setLayout(new BorderLayout());

        // Message Area
        messageArea = new JTextArea(10, 25); // Αύξηση των γραμμών και του πλάτους για την περιοχή μηνυμάτων
        messageArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(messageArea);
        add(scrollPane, BorderLayout.NORTH);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new GridLayout(4, 1, 5, 5)); // 4 rows, 1 column, gaps of 5 pixels
        buttonsPanel.setBorder(new TitledBorder("Controls"));

        //Δημιουργεια κουμπιων
        buyButton = createStyledButton("Buy");
        payButton = createStyledButton("Pay");
        rollDiceButton = createStyledButton("Roll Dice");
        endTurnButton = createStyledButton("End Turn");

        buttonsPanel.add(buyButton);
        buttonsPanel.add(payButton);
        buttonsPanel.add(rollDiceButton);
        buttonsPanel.add(endTurnButton);
        add(buttonsPanel, BorderLayout.CENTER);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(60, 25)); // Μικρότερο μέγεθος κουμπιών
        button.setFont(new Font("Arial", Font.PLAIN, 12)); // Αλλαγή της γραμματοσειράς
        button.setBackground(new Color(100, 149, 237)); // Απαλό μπλε χρώμα φόντου
        button.setForeground(Color.WHITE); // Άσπρο χρώμα κειμένου
        button.setFocusPainted(false); // Αφαίρεση του περιγράμματος όταν το κουμπί έχει την εστίαση
        button.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Padding μέσα στο κουμπί
        return button;
    }

    public void displayMessage(String message) {
        messageArea.setText(message); // Clear previous message and set new message
    }

    public JButton getBuyButton() {
        return buyButton;
    }

    public JButton getPayButton() {
        return payButton;
    }

    public JButton getRollDiceButton() {
        return rollDiceButton;
    }

    public JButton getEndTurnButton() {
        return endTurnButton;
    }
}





