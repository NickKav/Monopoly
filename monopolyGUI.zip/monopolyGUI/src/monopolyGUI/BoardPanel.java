package monopolyGUI;

import javax.swing.*;
import java.awt.*;
import java.net.URL;
import java.util.List;

public class BoardPanel extends JPanel {
    private List<BoardSpace> boardSpaces;
    private Image logoImage;

    public BoardPanel(List<BoardSpace> boardSpaces) {
        this.boardSpaces = boardSpaces;
        setPreferredSize(new Dimension(1000, 1000)); // Αύξηση του μεγέθους του ταμπλό
        setBackground(new Color(173, 255, 50)); // Κίτρινο-πράσινο χρώμα

        // Φόρτωση εικόνας JPEG από τον φάκελο resources
        URL imageURL = getClass().getResource("/resources/monopoly_logo.jpeg");
        if (imageURL != null) {
            logoImage = new ImageIcon(imageURL).getImage();
        } else {
            System.err.println("Cannot find image: your_image.jpeg");
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawBoard(g);
        drawLogo(g);
    }

    private void drawBoard(Graphics g) {
        int tileWidth = 120; // Αυξημένο πλάτος τετραγώνων
        int tileHeight = 113; // Αυξημένο ύψος τετραγώνων

        // Σχεδιάζουμε το ταμπλό γύρω από τα άκρα
        for (int i = 0; i < 7; i++) {
            drawTile(g, boardSpaces.get(i), i * tileWidth, 0, tileWidth, tileHeight); // Top row
            drawTile(g, boardSpaces.get(21 + i), 0, i * tileHeight, tileWidth, tileHeight); // Left column
            drawTile(g, boardSpaces.get(7 + i), i * tileWidth, 6 * tileHeight, tileWidth, tileHeight); // Bottom row
            drawTile(g, boardSpaces.get(14 + i), 6 * tileWidth, i * tileHeight, tileWidth, tileHeight); // Right column
        }
    }

    private void drawLogo(Graphics g) {
        if (logoImage != null) {
            // Κέντρο οριζόντια, με μια μικρή μείωση για να μετακινηθεί αριστερά
            int logoX = (getWidth() - logoImage.getWidth(this)) / 2 - 30; // Μείωση κατά 20 pixels

            // Κέντρο κατακόρυφα
            int logoY = (getHeight() - logoImage.getHeight(this)) / 2;

            g.drawImage(logoImage, logoX, logoY, this);
        }
    }





    private void drawTile(Graphics g, BoardSpace space, int x, int y, int width, int height) {
        g.setColor(Color.BLACK);
        g.drawRect(x, y, width, height);
        g.drawString(space.getName(), x + 5, y + 15);
    }
}








